package com.thargyi.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    // Set this to your HTTPS backend URL. Never put a private AI API key in the APK.
    private static final String BACKEND_URL = "https://YOUR_BACKEND_DOMAIN/chat";
    private LinearLayout messages;
    private EditText input;
    private TextView status;
    private SpeechRecognizer speech;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int navy = Color.rgb(7,20,38), blue = Color.rgb(28,144,230);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("my", "MM"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) status.setText("မြန်မာအသံ မရရှိပါက ဖုန်း TTS မှာ Burmese voice ထည့်ပါ");
            }
        });
        addMessage("သားကြီး AI မှ ကြိုဆိုပါတယ်။ ဘာကူညီပေးရမလဲ? 💙", false);
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(navy);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setGravity(Gravity.CENTER); header.setPadding(16,22,16,16);
        TextView title = text("သားကြီး AI", 27, Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        TextView sub = text("ကိုယ်ပိုင် AI အဖော် • မြန်မာဘာသာ", 13, 0xff9edcff);
        header.addView(title); header.addView(sub); root.addView(header);
        status = text("အဆင်သင့်ပါပြီ", 12, 0xff9edcff); status.setGravity(Gravity.CENTER); status.setPadding(8,4,8,8); root.addView(status);
        ScrollView scroll = new ScrollView(this); messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); messages.setPadding(14,8,14,8); scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar = new LinearLayout(this); bar.setPadding(10,10,10,14); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(0xff0c2039);
        input = new EditText(this); input.setSingleLine(true); input.setTextColor(Color.WHITE); input.setHintTextColor(0xff9aafc5); input.setHint("မေးချင်တာ ရေးပါ..."); input.setPadding(14,10,14,10); input.setBackground(bg(0xff18314d,28));
        bar.addView(input,new LinearLayout.LayoutParams(0,50,1));
        Button mic = button("🎤", 0xff174b78); Button send = button("ပို့မယ်", blue);
        bar.addView(mic); bar.addView(send); root.addView(bar); setContentView(root);
        send.setOnClickListener(v -> sendText()); mic.setOnClickListener(v -> startVoice());
    }
    private Button button(String label, int color) { Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(13); b.setAllCaps(false); b.setBackground(bg(color,24)); return b; }
    private void addMessage(String s, boolean user) {
        TextView bubble = text(s, 16, Color.WHITE); bubble.setPadding(14,11,14,11); bubble.setBackground(bg(user ? 0xff145a91 : 0xff18314d,18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2,-2); p.setMargins(user?50:0,6,user?0:50,6); p.gravity = user ? Gravity.RIGHT : Gravity.LEFT; messages.addView(bubble,p);
    }
    private void sendText() {
        String q = input.getText().toString().trim(); if(q.isEmpty()) return;
        input.setText(""); addMessage(q,true); status.setText("AI က စဉ်းစားနေပါတယ်...");
        new Thread(() -> {
            try {
                if (BACKEND_URL.contains("YOUR_BACKEND_DOMAIN")) throw new Exception("AI ချိတ်ဆက်ရန် backend URL ကို အရင်သတ်မှတ်ပေးပါ။");
                HttpURLConnection c=(HttpURLConnection)new URL(BACKEND_URL).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                JSONObject body=new JSONObject(); body.put("message",q);
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                InputStream is=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[2048]; int n; while((n=is.read(buf))!=-1)out.write(buf,0,n);
                JSONObject response=new JSONObject(out.toString("UTF-8")); String reply=response.optString("reply","အဖြေမရရှိပါ။");
                runOnUiThread(()->{addMessage(reply,false); status.setText("အဆင်သင့်ပါပြီ"); speak(reply);}); c.disconnect();
            } catch(Exception e) { runOnUiThread(()->{addMessage("AI ချိတ်ဆက်မှု မပြီးသေးပါ။ "+e.getMessage(),false); status.setText("Backend ချိတ်ဆက်ရန် လိုအပ်သည်");}); }
        }).start();
    }
    private void speak(String s) { if(tts!=null && ttsReady) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"reply"); }
    private void startVoice() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("ဒီဖုန်းမှာ Speech Recognition မရရှိပါ");return;}
        if(speech!=null) speech.destroy(); speech=SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){status.setText("နားထောင်နေပါတယ်... ပြောပါ");}
            public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(r!=null&&!r.isEmpty()){input.setText(r.get(0));sendText();}}
            public void onError(int e){status.setText("အသံမကြားရပါ။ ထပ်စမ်းကြည့်ပါ");}
            public void onBeginningOfSpeech(){} public void onRmsChanged(float v){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){status.setText("အသံကို စာသားပြောင်းနေပါတယ်...");} public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"my-MM"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"my-MM"); speech.startListening(i);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startVoice();}
    @Override protected void onDestroy(){if(speech!=null)speech.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
